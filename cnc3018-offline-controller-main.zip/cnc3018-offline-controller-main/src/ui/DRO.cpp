#include "DRO.h"

constexpr int DRO::JOG_FEEDS[];
constexpr float DRO::JOG_DISTS[];
constexpr int DRO::SPINDLE_VALS[];